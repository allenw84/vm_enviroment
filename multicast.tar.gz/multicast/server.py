import socket
import time
import binascii
import sys

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
server.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
# Set a timeout so the socket does not block
# indefinitely when trying to receive data.
server.settimeout(0.2)
server.bind(("", 44444))
fh = open(r'1.jpg','rb')
fh2 = open(r'2.jpg','rb')
fh3 = open(r'3.jpg','rb')
a = fh.read()
b = fh2.read()
c = fh3.read()

fh.close()

message = b"1234"

# hexstr = binascii.b2a_hex(a)
# print(sys.getsizeof(hexstr))
# hexstr = binascii.b2a_hex(b)
# print(sys.getsizeof(hexstr))
# hexstr = binascii.b2a_hex(c)
# print(sys.getsizeof(hexstr))
#轉二進制
#img = binascii.a2b_hex(hexstr)
#save image
#image = wx.ImageFromStream(cStringIO.StringIO(img), wx.BITMAP_TYPE_JPEG)
#image.SaveFile('temp.jpg', wx.BITMAP_TYPE_JPEG)
i = 1
# hexstr = 1
while True:

	if i%3 == 1:
		hexstr = binascii.b2a_hex(a)
	elif i%3 == 2:
		hexstr = binascii.b2a_hex(b)
	else:
		hexstr = binascii.b2a_hex(c)

	server.sendto(hexstr, ('192.168.50.255', 37020))
	print("message sent!")
	time.sleep(1)

	i = i + 1

